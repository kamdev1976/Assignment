import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material';
import { FormsModule } from '@angular/forms';

import { SpinnerComponent } from './spinner.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        MatCardModule
    ],
    declarations: [SpinnerComponent],
    exports: [SpinnerComponent],
})
export class SpinnerModule {
}