import {
    Component,
    OnChanges,
    Input,
    SimpleChanges,
} from '@angular/core';

@Component({
    selector: 'app-spinner',
    templateUrl: './spinner.component.html',
    styleUrls: ['./spinner.component.sass']
})
export class SpinnerComponent implements OnChanges {
    @Input() options;

    constructor() { }

    ngOnChanges(changes: SimpleChanges) {
        if (changes.hasOwnProperty('options')) {
            this.options = changes.options.currentValue;
        }
    }

}