import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';

import * as models from '../models/models';
import * as urls from '../constants/endpoints.constants';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';


const headers = {
    headers: new HttpHeaders({ Accept: 'multipart/form-data' })
};
const httpHeaders = new HttpHeaders().set('Accept', 'application/pdf');

const httpRequestOptions = {
    headers: new HttpHeaders({
        'Access-Control-Allow-Origin': '*',
        //'Content-Type': 'application/json; charset=utf-8',
    })
};

@Injectable({
    providedIn: 'root',
})
export class FsDataService {

    private current_user;


    constructor(
        private http: HttpClient,
    ) { }

    // initializeApp(): Promise<IUserResponse> {
    //     return this.getUser().toPromise()
    //         .then(
    //             res => {
    //                 this.current_user = res.user;
    //                 return res;
    //             },
    //         );
    // }

    // public getUser(): Observable<IUserResponse> {
    //     return this.http.get<IUserResponse>(urls.UserURL);
    // }

    // public getCurrentUser(): IUserResponse {
    //     return this.current_user;
    // }

    // public getUsers() {
    //     return this.http.get<models.DataModel>(urls.UsersURL);
    // }



    public getUsers() {
        return this.http.get<any>(urls.GetUsers);
    }

    public addUser(data): Observable<models.User> {
        return this.http.post<models.User>(urls.AddUser, data, httpRequestOptions);
    }
}
