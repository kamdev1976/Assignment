export class DataModel {
    data?: any;
    access?: boolean;
    avatar?: string;
}

export class User {
    RegistrationId: number;
    FirstName: string;
    LastName: string;
    Age: number;
    Photo: File
}