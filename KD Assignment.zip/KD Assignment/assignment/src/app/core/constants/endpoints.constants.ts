
const apiBase = 'https://localhost:44328/api/';

export const GetUsers = `${apiBase}UserRegister/GetUserList`;
export const AddUser = `${apiBase}UserRegister/AddUser`;