import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormComponent } from './component/form/form.component';
import { HeaderComponent } from './component/header/header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ToastrModule } from 'ngx-toastr';

import {
  // MatCardModule,
  // MatCheckboxModule,
  MatInputModule,
  MatCardModule,
  MatTableModule,
  MatSortModule,
  MatPaginatorModule,
  // MatSelectModule,
  // MatTooltipModule,
  // MatTabsModule,
  // MatDialogModule,
  // MatRadioModule,
  // MatAutocompleteModule,
  // MatExpansionModule
} from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { HttpClientModule } from '@angular/common/http';
import { SpinnerModule } from './shared/spinner/spinner.module';
@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    HeaderComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatCardModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    HttpClientModule,
    SpinnerModule,
    ToastrModule.forRoot({
      timeOut: 8000,
      preventDuplicates: true
    }),
  ],
  providers: [],
  //   providers: [
  //     DatePipe,
  //     {
  //         provide: APP_INITIALIZER,
  //         useFactory: (dataService: FsDataService) => () => dataService.initializeApp(),
  //         deps: [FsDataService],
  //         multi: true
  //     },
  // ],
  bootstrap: [AppComponent]
})
export class AppModule { }
