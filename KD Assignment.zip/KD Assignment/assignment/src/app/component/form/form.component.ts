import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { finalize } from 'rxjs/operators';
import { FsDataService } from '../../core/services/fs-data.service'
import { User } from 'src/app/core/models/models';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.sass']
})

export class FormComponent implements OnInit {

  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  public profile_form = this.fb.group({
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    age: ['', Validators.required],
    photo: [''],
    registrationId: ['']
  });

  private displayedColumns = ['Name', 'Age', 'Photo'];// columns that will be displayed

  private dataSource = new MatTableDataSource<User>(User_Data);

  public options = {
    is_loading: true,
    not_fluid: true,
  };

  constructor(
    private fb: FormBuilder,
    private toastr: ToastrService,
    private dataService: FsDataService
  ) { }

  ngOnInit() {
    this.getDataforTable();
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }
  get firstName() {
    return this.profile_form.get('firstName');
  }

  get lastName() {
    return this.profile_form.get('lastName');
  }

  get age() {
    return this.profile_form.get('age');
  }

  //to call get api 
  getDataforTable() {
    this.dataService.getUsers()
      .pipe(
        finalize(() => {
          this.options.is_loading = false;
        })
      ).subscribe(
        res => {
          this.dataSource = res;
        },
        err => { console.error(err); }
      );
  }

  //to post data api
  public saveProfile(): void {
    const data = {
      RegistrationId: 0,
      FirstName: this.profile_form.controls.firstName.value,
      LastName: this.profile_form.controls.lastName.value,
      //Photo: this.photo,
      Age: Number(this.profile_form.controls.age.value)
    }

    console.log(this.profile_form.value);

    this.dataService
      .addUser(data)
      .subscribe(
        () => {
          this.toastr.success('Saved Successfully.');
          this.getDataforTable();
        },
        error => { throw error; }
      );
  }
  public photo: any;

  onFileChange(event: any) {
    if (event.target.files && event.target.files[0]) {
      this.photo = event.target.files[0];
      this.profile_form.get('photo').setValue(this.photo);
      // const reader = new FileReader();
      // reader.onload = (event2: ProgressEvent) => {
      //   this.photo = (event2.target as FileReader).result;
      // };
      // reader.readAsDataURL(event.target.files[0]);
    }
  }

  // saveData() {
  //   const input = new FormData();
  //   input.append('RegistrationId', '0');
  //   input.append('FirstName', this.profile_form.controls.firstName.value);
  //   input.append('LastName', this.profile_form.controls.lastName.value);
  //   input.append('Age', this.profile_form.controls.age.value);
  //   input.append('Photo', this.profile_form.get('photo').value);

  //   this.dataService
  //     .addUser(input)
  //     .subscribe(
  //       () => {
  //         this.toastr.success('Saved Successfully.');
  //         this.getDataforTable();
  //       },
  //       error => { throw error; }
  //     );

  // }

}

const User_Data: User[] = [];